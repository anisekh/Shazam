//
//  ShazamApp.swift
//  Shazam
//
//  Created by Aniseh Khajuei on 10/11/25.
//

import SwiftUI

@main
struct ShazamApp: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
