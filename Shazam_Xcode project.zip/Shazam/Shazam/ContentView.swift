//
//  ContentView.swift
//  Shazam
//
//  Created by Aniseh Khajuei on 10/11/25.
//

import SwiftUI

struct ContentView: View {
    var body: some View {
        ShazamPulseView()

    }
}

#Preview {
    ShazamPulseView()
}
